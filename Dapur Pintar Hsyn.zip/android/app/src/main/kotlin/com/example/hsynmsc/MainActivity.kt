package com.example.hsynmsc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
