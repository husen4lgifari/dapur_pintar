import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Profile"),
        backgroundColor: Color(0xccfefaf8),
      ),
      body: Column(
        children: [
          SizedBox(height: 20),
          Center(
            child: CircleAvatar(
              radius: 80,
              backgroundImage: NetworkImage(
                "https://github.com/Husen844algifari/img/blob/main/ucennn.jpg?raw=true",
              ),
            ),
          ),
          SizedBox(height: 20),
          ListTile(
            leading: Icon(Icons.person),
            title: Text("Nama"),
            subtitle: Text("Husen Algifari"),
          ),
          ListTile(
            leading: Icon(Icons.phone),
            title: Text("No.Telepon"),
            subtitle: Text("083129055606"),
          ),
          ListTile(
            leading: Icon(Icons.email),
            title: Text("Email"),
            subtitle: Text("husenalgifari38@gmail.com"),
          ),
        ],
      ),
    );
  }
}
