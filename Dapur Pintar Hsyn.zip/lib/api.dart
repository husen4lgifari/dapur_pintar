import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String apiUrl =
      'https://673db15c0118dbfe86085765.mockapi.io/resep/resep';

  Future<List<dynamic>> fetchRecipes() async {
    final response = await http.get(Uri.parse(apiUrl));
    if (response.statusCode == 200) {
      final List<dynamic> recipes = json.decode(response.body);
      return recipes;
    } else {
      throw Exception('Failed to load recipes');
    }
  }
}
