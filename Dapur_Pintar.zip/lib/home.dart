import 'package:flutter/material.dart';
import 'api.dart';
import 'resep.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late Future<List<dynamic>> recipes;
  late Map<String, List<dynamic>> categorizedRecipes;

  @override
  void initState() {
    super.initState();
    recipes = ApiService().fetchRecipes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dapur Pintar'),
        backgroundColor: Color(0xccfefaf8),
        elevation: 0,
      ),
      body: FutureBuilder<List<dynamic>>(
        future: recipes,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No Recipes Found'));
          } else {
            List<dynamic> categories = snapshot.data!;

            // Mengelompokkan resep berdasarkan kategori
            categorizedRecipes = {};
            for (var recipe in categories) {
              String category = recipe['category'];
              if (!categorizedRecipes.containsKey(category)) {
                categorizedRecipes[category] = [];
              }
              categorizedRecipes[category]?.add(recipe);
            }

            return SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: categorizedRecipes.keys.map((category) {
                    return Card(
                      margin: EdgeInsets.only(bottom: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 6, // Add shadow effect
                      child: InkWell(
                        onTap: () {
                          // Navigasi ke halaman resep sesuai kategori
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ResepPage(
                                category: category,
                                recipes: categorizedRecipes[category]!,
                              ),
                            ),
                          );
                        },
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: Stack(
                            children: [
                              Container(
                                height: 150,
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: NetworkImage(
                                        categorizedRecipes[category]![0]
                                            ['image']),
                                    fit: BoxFit.cover,
                                  ),
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(16),
                                  ),
                                ),
                              ),
                              // Semi-transparent overlay to darken the image
                              Container(
                                height: 150,
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.4),
                                  borderRadius: BorderRadius.vertical(
                                    top: Radius.circular(16),
                                  ),
                                ),
                              ),
                              // Category text centered in the image
                              Positioned(
                                top: 50,
                                left: 0,
                                right: 0,
                                child: Center(
                                  child: Text(
                                    category,
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                              // Duration at bottom-right corner
                              Positioned(
                                bottom: 10,
                                right: 10,
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.7),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    '10-15 min',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                              ),
                              // Rating and star image at bottom-left corner
                              Positioned(
                                bottom: 10,
                                left: 10,
                                child: Row(
                                  children: [
                                    Icon(Icons.star,
                                        color: Colors.amber, size: 16),
                                    SizedBox(width: 4),
                                    Text(
                                      '4.5',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            );
          }
        },
      ),
    );
  }
}
