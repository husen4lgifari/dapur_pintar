import 'package:flutter/material.dart';

class ResepPage extends StatelessWidget {
  final String category;
  final List<dynamic> recipes;

  ResepPage({required this.category, required this.recipes});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(category),
        backgroundColor: Color(0xccfefaf8),
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: recipes.length,
        itemBuilder: (context, index) {
          var recipe = recipes[index];
          return Card(
            margin: EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            elevation: 6, // Add shadow effect
            child: InkWell(
              onTap: () {
                // Open the recipe details
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => IsiResepPage(recipe: recipe),
                  ),
                );
              },
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Stack(
                  children: [
                    Image.network(
                      recipe['image'],
                      fit: BoxFit.cover,
                      height: 250, // Setting fixed height for image
                      width: double.infinity,
                    ),
                    // Semi-transparent overlay to darken the image
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.5),
                        borderRadius: BorderRadius.vertical(
                          top: Radius.circular(16),
                        ),
                      ),
                      height: 250, // Fixed height for the container
                      width: double.infinity,
                      child: Center(
                        child: Text(
                          recipe['title'],
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class IsiResepPage extends StatelessWidget {
  final dynamic recipe;

  IsiResepPage({required this.recipe});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(recipe['title']),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.network(recipe['image']),
              SizedBox(height: 16),
              Text(
                recipe['title'],
                style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),
              Text('Ingredients:', style: TextStyle(fontSize: 18)),
              SizedBox(height: 8),
              Text(recipe['ingredients']),
            ],
          ),
        ),
      ),
    );
  }
}
