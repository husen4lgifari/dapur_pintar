import 'package:flutter/material.dart';
import 'home.dart';
import 'profile.dart'; // File Profile, kita buat berikutnya

class BottomNavPage extends StatefulWidget {
  @override
  _BottomNavPageState createState() => _BottomNavPageState();
}

class _BottomNavPageState extends State<BottomNavPage> {
  int _selectedIndex = 0; // Menyimpan index yang dipilih

  // Daftar halaman yang ditampilkan berdasarkan tab
  final List<Widget> _pages = [
    HomePage(), // Halaman Home
    ProfilePage(), // Halaman Profile
  ];

  // Fungsi untuk mengubah halaman berdasarkan index yang dipilih
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex], // Menampilkan halaman sesuai index
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex, // Menyinkronkan dengan index yang dipilih
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
